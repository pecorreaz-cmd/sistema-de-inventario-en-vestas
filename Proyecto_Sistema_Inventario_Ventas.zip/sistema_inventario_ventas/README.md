# Sistema Web de Gestión de Inventario y Ventas

Proyecto académico desarrollado con PHP, MySQL, HTML y CSS. Incluye autenticación de usuarios, panel principal y módulos de gestión.

## Requisitos
- XAMPP (Apache y MySQL) o un entorno equivalente.
- PHP 8.0 o superior recomendado.
- MySQL/MariaDB.
- Navegador web.

## Instalación en XAMPP
1. Copia la carpeta `sistema_inventario_ventas` dentro de `C:\xampp\htdocs\`.
2. Abre el panel de XAMPP e inicia **Apache** y **MySQL**.
3. Entra a `http://localhost/phpmyadmin`.
4. Selecciona la pestaña **Importar** y carga el archivo `database.sql`.
5. Verifica los datos de conexión en `config.php`. En una instalación normal de XAMPP, el usuario es `root` y la contraseña queda vacía.
6. Abre `http://localhost/sistema_inventario_ventas/setup_admin.php` una sola vez para crear el usuario inicial.
7. Ingresa en `http://localhost/sistema_inventario_ventas/`.
8. Por seguridad, elimina `setup_admin.php` después de crear el usuario.

## Credenciales iniciales
- Correo: `admin@demo.com`
- Contraseña: `Admin123*`

Cambia la contraseña después de ingresar y no uses estas credenciales en un servidor público.

## Módulos
- Usuarios: crear, leer, actualizar y eliminar. Las contraseñas se almacenan con `password_hash`.
- Productos: CRUD de productos, precio y stock.
- Clientes: CRUD de clientes.
- Ventas: registrar y consultar ventas, eliminar ventas y devolver el stock al inventario.
- Detalle de ventas: relaciona ventas y productos.

## Relaciones principales
- `sales.client_id` → `clients.id`
- `sales.user_id` → `users.id`
- `sale_details.sale_id` → `sales.id`
- `sale_details.product_id` → `products.id`

## Pruebas sugeridas
1. Iniciar sesión con las credenciales de demostración.
2. Crear un producto de prueba.
3. Editar el precio o el stock.
4. Registrar un cliente.
5. Editar los datos del cliente y luego eliminar un registro de prueba.
6. Crear una venta, comprobar que el stock disminuye y luego eliminarla para comprobar que el stock se devuelve.
7. Cerrar sesión y confirmar que el sistema vuelve al login.
8. Intentar acceder a `dashboard.php` sin sesión: debe redirigir a `login.php`.

## Publicación en GitHub
1. Crea un repositorio nuevo en GitHub, por ejemplo `sistema-inventario-ventas`.
2. Descomprime la carpeta del proyecto.
3. Sube los archivos del proyecto al repositorio. No subas contraseñas reales ni datos privados.
4. Copia el enlace del repositorio y pégalo en la tarea de la plataforma.

## Defensa sugerida (3 a 5 minutos)
- Presenta el nombre y objetivo del sistema.
- Muestra el login y explica la validación de credenciales.
- Enseña el panel principal y la navegación.
- Demuestra crear, consultar, editar y eliminar un producto, un cliente y un usuario (usa datos de prueba).
- Registra una venta y enseña cómo cambia el stock.
- Explica las relaciones entre las tablas de la base de datos.
- Finaliza mostrando el repositorio GitHub.

## Observaciones
- Este proyecto debe probarse en tu computadora antes de entregarlo.
- La base de datos debe importarse y el usuario inicial debe crearse siguiendo los pasos indicados.
- La aplicación es una base académica funcional; antes de publicarla en Internet, se recomienda añadir protección CSRF, permisos más detallados y configuración segura del servidor.
