<?php
require_once 'config.php';
require_once 'includes/auth.php';
require_login();
$message=''; $error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $action=$_POST['action']??'';
  try {
    if ($action==='save') {
      $client=(int)($_POST['client_id']??0);
      $product=(int)($_POST['product_id']??0);
      $qty=(int)($_POST['quantity']??0);
      if ($client<1 || $product<1 || $qty<1) throw new RuntimeException('Selecciona un cliente, un producto y una cantidad válida.');
      $pdo->beginTransaction();
      $stmt=$pdo->prepare('SELECT precio, stock, nombre FROM products WHERE id=? FOR UPDATE'); $stmt->execute([$product]); $p=$stmt->fetch();
      if (!$p) throw new RuntimeException('El producto seleccionado no existe.');
      if ((int)$p['stock']<$qty) throw new RuntimeException('No hay suficiente stock para completar la venta.');
      $stmt=$pdo->prepare('INSERT INTO sales (client_id,user_id,total,fecha) VALUES (?,?,?,NOW())');
      $total=(float)$p['precio']*$qty; $stmt->execute([$client,(int)$_SESSION['user_id'],$total]); $saleId=(int)$pdo->lastInsertId();
      $stmt=$pdo->prepare('INSERT INTO sale_details (sale_id,product_id,quantity,unit_price,subtotal) VALUES (?,?,?,?,?)');
      $stmt->execute([$saleId,$product,$qty,$p['precio'],$total]);
      $stmt=$pdo->prepare('UPDATE products SET stock=stock-? WHERE id=?'); $stmt->execute([$qty,$product]);
      $pdo->commit(); $message='Venta registrada y stock actualizado correctamente.';
    } elseif ($action==='delete') {
      $id=(int)($_POST['id']??0);
      $pdo->beginTransaction();
      $stmt=$pdo->prepare('SELECT product_id,quantity FROM sale_details WHERE sale_id=?'); $stmt->execute([$id]); $details=$stmt->fetchAll();
      foreach($details as $d) { $st=$pdo->prepare('UPDATE products SET stock=stock+? WHERE id=?'); $st->execute([$d['quantity'],$d['product_id']]); }
      $st=$pdo->prepare('DELETE FROM sales WHERE id=?'); $st->execute([$id]);
      $pdo->commit(); $message='Venta eliminada y stock devuelto al inventario.';
    }
  } catch(Throwable $ex) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    $error=$ex->getMessage();
  }
}
$clients=$pdo->query('SELECT id,nombre FROM clients ORDER BY nombre')->fetchAll();
$products=$pdo->query('SELECT id,nombre,precio,stock FROM products ORDER BY nombre')->fetchAll();
$sales=$pdo->query('SELECT s.id,s.fecha,s.total,c.nombre AS cliente,u.nombre AS usuario, GROUP_CONCAT(CONCAT(p.nombre, " × ", d.quantity) SEPARATOR ", ") AS detalle FROM sales s JOIN clients c ON c.id=s.client_id JOIN users u ON u.id=s.user_id LEFT JOIN sale_details d ON d.sale_id=s.id LEFT JOIN products p ON p.id=d.product_id GROUP BY s.id ORDER BY s.id DESC')->fetchAll();
$page_title='Gestión de ventas'; require 'includes/header.php';
?>
<div class="page-heading"><div><span class="eyebrow">TRANSACCIONES</span><h1>Ventas</h1><p>Registra ventas, consulta sus detalles y controla el inventario.</p></div></div>
<?php if($message): ?><div class="alert success"><?= e($message) ?></div><?php endif; ?>
<?php if($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<section class="panel"><h2>Registrar una venta</h2>
<?php if(!$clients || !$products): ?><div class="alert error">Primero registra al menos un cliente y un producto con stock disponible.</div><?php else: ?>
<form method="post" class="form-grid"><input type="hidden" name="action" value="save">
<div class="field"><label>Cliente *</label><select name="client_id" required><option value="">Selecciona un cliente</option><?php foreach($clients as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['nombre']) ?></option><?php endforeach; ?></select></div>
<div class="field"><label>Producto *</label><select name="product_id" required><?php foreach($products as $p): ?><option value="<?= (int)$p['id'] ?>" <?= (int)$p['stock']<1?'disabled':'' ?>><?= e($p['nombre']) ?> — $<?= number_format((float)$p['precio'],2) ?> (stock: <?= (int)$p['stock'] ?>)</option><?php endforeach; ?></select></div>
<div class="field"><label>Cantidad *</label><input type="number" name="quantity" min="1" step="1" required></div>
<div class="form-actions"><button class="btn primary" type="submit">Registrar venta</button></div></form>
<?php endif; ?></section>
<section class="panel"><div class="section-title"><h2>Historial de ventas</h2><span class="pill"><?= count($sales) ?> ventas</span></div><div class="table-wrap"><table><thead><tr><th>ID</th><th>Fecha</th><th>Cliente</th><th>Registró</th><th>Detalle</th><th>Total</th><th>Acciones</th></tr></thead><tbody>
<?php if(!$sales): ?><tr><td colspan="7" class="empty">Todavía no hay ventas registradas.</td></tr><?php endif; ?>
<?php foreach($sales as $s): ?><tr><td><?= (int)$s['id'] ?></td><td><?= e($s['fecha']) ?></td><td><?= e($s['cliente']) ?></td><td><?= e($s['usuario']) ?></td><td><?= e($s['detalle']??'') ?></td><td>$<?= number_format((float)$s['total'],2) ?></td><td><form method="post" onsubmit="return confirm('¿Eliminar esta venta y devolver los productos al inventario?');"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$s['id'] ?>"><button class="btn tiny danger">Eliminar</button></form></td></tr><?php endforeach; ?>
</tbody></table></div></section>
<?php require 'includes/footer.php'; ?>
