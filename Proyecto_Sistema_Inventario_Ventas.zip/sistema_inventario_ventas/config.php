<?php
declare(strict_types=1);
session_start();

$host = 'localhost';
$db   = 'inventario_ventas';
$user = 'root';
$pass = ''; // Cambia esta clave si tu MySQL tiene contraseña.
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    http_response_code(500);
    exit('No se pudo conectar a la base de datos. Verifica config.php y ejecuta database.sql. Detalle: ' . htmlspecialchars($e->getMessage()));
}
