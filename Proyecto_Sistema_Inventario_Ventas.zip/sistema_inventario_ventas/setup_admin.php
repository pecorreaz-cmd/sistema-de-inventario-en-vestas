<?php
// Ejecuta este archivo una sola vez desde el navegador y luego ELIMÍNALO por seguridad.
require_once 'config.php';
$email='admin@demo.com';
$password='Admin123*';
$stmt=$pdo->prepare('SELECT id FROM users WHERE email=?');
$stmt->execute([$email]);
if($stmt->fetch()) {
    echo 'El usuario admin@demo.com ya existe. Elimina setup_admin.php por seguridad.';
    exit;
}
$stmt=$pdo->prepare('INSERT INTO users (nombre,email,password_hash,rol) VALUES (?,?,?,?)');
$stmt->execute(['Administrador Demo',$email,password_hash($password,PASSWORD_DEFAULT),'Administrador']);
echo 'Usuario creado correctamente. Correo: admin@demo.com | Contraseña: Admin123*. Ahora elimina setup_admin.php.';
