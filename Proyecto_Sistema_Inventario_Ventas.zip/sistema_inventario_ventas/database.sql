CREATE DATABASE IF NOT EXISTS inventario_ventas CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE inventario_ventas;

CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nombre VARCHAR(120) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 rol ENUM('Administrador','Empleado') NOT NULL DEFAULT 'Empleado',
 creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nombre VARCHAR(140) NOT NULL,
 descripcion TEXT NULL,
 precio DECIMAL(10,2) NOT NULL DEFAULT 0,
 stock INT NOT NULL DEFAULT 0,
 creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS clients (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nombre VARCHAR(140) NOT NULL,
 cedula VARCHAR(20) NOT NULL UNIQUE,
 telefono VARCHAR(30) NULL,
 email VARCHAR(150) NULL,
 creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sales (
 id INT AUTO_INCREMENT PRIMARY KEY,
 client_id INT NOT NULL,
 user_id INT NOT NULL,
 fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 total DECIMAL(10,2) NOT NULL DEFAULT 0,
 CONSTRAINT fk_sales_client FOREIGN KEY (client_id) REFERENCES clients(id),
 CONSTRAINT fk_sales_user FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS sale_details (
 id INT AUTO_INCREMENT PRIMARY KEY,
 sale_id INT NOT NULL,
 product_id INT NOT NULL,
 quantity INT NOT NULL,
 unit_price DECIMAL(10,2) NOT NULL,
 subtotal DECIMAL(10,2) NOT NULL,
 CONSTRAINT fk_detail_sale FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
 CONSTRAINT fk_detail_product FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Usuario inicial de demostración.
-- La contraseña es Admin123*; el hash se inserta desde setup_admin.php para mayor compatibilidad.
