<?php
require_once 'config.php';
if (!empty($_SESSION['user_id'])) { header('Location: dashboard.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = $pdo->prepare('SELECT id, nombre, email, password_hash, rol FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$user['id'];
        $_SESSION['user_name'] = $user['nombre'];
        $_SESSION['user_role'] = $user['rol'];
        header('Location: dashboard.php'); exit;
    }
    $error = 'Correo o contraseña incorrectos.';
}
$page_title = 'Iniciar sesión';
require 'includes/header.php';
?>
<section class="login-card">
  <div class="login-icon">🔐</div>
  <h1>Iniciar sesión</h1>
  <p class="muted">Ingresa tus credenciales para administrar el sistema.</p>
  <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
  <form method="post">
    <label>Correo electrónico</label>
    <input type="email" name="email" required autocomplete="username" placeholder="admin@demo.com">
    <label>Contraseña</label>
    <input type="password" name="password" required autocomplete="current-password" placeholder="Tu contraseña">
    <button class="btn primary full" type="submit">Ingresar</button>
  </form>
  <div class="demo"><strong>Acceso inicial de demostración</strong><br>Correo: admin@demo.com<br>Contraseña: Admin123*</div>
</section>
<?php require 'includes/footer.php'; ?>
