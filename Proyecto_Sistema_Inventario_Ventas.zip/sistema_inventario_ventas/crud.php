<?php
// Motor CRUD compartido por usuarios, productos y clientes.
require_once 'config.php';
require_once 'includes/auth.php';
require_login();

$resources = [
 'users' => [
  'title'=>'Usuarios', 'table'=>'users',
  'fields'=>[
   'nombre'=>['label'=>'Nombre completo','type'=>'text','required'=>true],
   'email'=>['label'=>'Correo electrónico','type'=>'email','required'=>true],
   'rol'=>['label'=>'Rol','type'=>'select','options'=>['Administrador','Empleado'],'required'=>true],
  ],
  'columns'=>['id'=>'ID','nombre'=>'Nombre','email'=>'Correo electrónico','rol'=>'Rol'],
 ],
 'products' => [
  'title'=>'Productos', 'table'=>'products',
  'fields'=>[
   'nombre'=>['label'=>'Nombre del producto','type'=>'text','required'=>true],
   'descripcion'=>['label'=>'Descripción','type'=>'textarea','required'=>false],
   'precio'=>['label'=>'Precio ($)','type'=>'number','step'=>'0.01','min'=>'0','required'=>true],
   'stock'=>['label'=>'Cantidad en stock','type'=>'number','step'=>'1','min'=>'0','required'=>true],
  ],
  'columns'=>['id'=>'ID','nombre'=>'Producto','descripcion'=>'Descripción','precio'=>'Precio','stock'=>'Stock'],
 ],
 'clients' => [
  'title'=>'Clientes', 'table'=>'clients',
  'fields'=>[
   'nombre'=>['label'=>'Nombre completo','type'=>'text','required'=>true],
   'cedula'=>['label'=>'Cédula','type'=>'text','required'=>true],
   'telefono'=>['label'=>'Teléfono','type'=>'text','required'=>false],
   'email'=>['label'=>'Correo electrónico','type'=>'email','required'=>false],
  ],
  'columns'=>['id'=>'ID','nombre'=>'Nombre','cedula'=>'Cédula','telefono'=>'Teléfono','email'=>'Correo'],
 ],
];
$key = $_GET['r'] ?? 'products';
if (!isset($resources[$key])) { http_response_code(404); exit('Módulo no encontrado'); }
$cfg = $resources[$key];
$table = $cfg['table'];
$message = '';
$error = '';
$edit = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = (int)($_POST['id'] ?? 0);
    try {
        if ($action === 'save') {
            $data = [];
            foreach ($cfg['fields'] as $field=>$meta) {
                $value = trim((string)($_POST[$field] ?? ''));
                if (!empty($meta['required']) && $value === '') throw new RuntimeException('Completa todos los campos obligatorios.');
                $data[$field] = $value;
            }
            if ($key === 'users') {
                if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) throw new RuntimeException('El correo electrónico no es válido.');
                if ($id === 0) {
                    $password = $_POST['password'] ?? '';
                    if (strlen($password) < 8) throw new RuntimeException('La contraseña debe tener al menos 8 caracteres.');
                    $data['password_hash'] = password_hash($password, PASSWORD_DEFAULT);
                } elseif (!empty($_POST['password'])) {
                    if (strlen($_POST['password']) < 8) throw new RuntimeException('La nueva contraseña debe tener al menos 8 caracteres.');
                    $data['password_hash'] = password_hash($_POST['password'], PASSWORD_DEFAULT);
                }
            }
            if ($id > 0) {
                $set = [];
                foreach (array_keys($data) as $field) $set[] = "`$field` = ?";
                $values = array_values($data);
                $values[] = $id;
                $stmt = $pdo->prepare("UPDATE `$table` SET " . implode(', ', $set) . " WHERE id = ?");
                $stmt->execute($values);
                $message = 'Registro actualizado correctamente.';
            } else {
                $fields = array_keys($data);
                $marks = array_fill(0, count($fields), '?');
                $stmt = $pdo->prepare("INSERT INTO `$table` (`" . implode('`,`', $fields) . "`) VALUES (" . implode(',', $marks) . ")");
                $stmt->execute(array_values($data));
                $message = 'Registro creado correctamente.';
            }
        } elseif ($action === 'delete') {
            if ($key === 'users' && $id === (int)$_SESSION['user_id']) throw new RuntimeException('No puedes eliminar la cuenta con la que tienes la sesión iniciada.');
            $stmt = $pdo->prepare("DELETE FROM `$table` WHERE id = ?");
            $stmt->execute([$id]);
            $message = 'Registro eliminado correctamente.';
        }
    } catch (Throwable $ex) {
        if ($ex instanceof PDOException && $ex->getCode() === '23000') $error = 'No se pudo guardar: el correo o la cédula ya existe, o el registro está relacionado con otra información.';
        else $error = $ex->getMessage();
    }
}

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM `$table` WHERE id = ?");
    $stmt->execute([(int)$_GET['edit']]);
    $edit = $stmt->fetch() ?: null;
}
$rows = $pdo->query("SELECT * FROM `$table` ORDER BY id DESC")->fetchAll();
$page_title = 'Gestión de ' . $cfg['title'];
require 'includes/header.php';
?>
<div class="page-heading"><div><span class="eyebrow">ADMINISTRACIÓN</span><h1><?= e($cfg['title']) ?></h1><p>Registra, consulta, modifica y elimina información.</p></div></div>
<?php if ($message): ?><div class="alert success"><?= e($message) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<section class="panel">
<h2><?= $edit ? 'Editar registro' : 'Agregar nuevo registro' ?></h2>
<form method="post" class="form-grid">
<input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= e($edit['id'] ?? 0) ?>">
<?php foreach ($cfg['fields'] as $field=>$meta): ?>
<div class="field <?= $meta['type']==='textarea'?'wide':'' ?>">
<label><?= e($meta['label']) ?><?= !empty($meta['required'])?' *':'' ?></label>
<?php if ($meta['type']==='select'): ?>
<select name="<?= e($field) ?>" <?= !empty($meta['required'])?'required':'' ?>>
<?php foreach ($meta['options'] as $opt): ?><option value="<?= e($opt) ?>" <?= (($edit[$field] ?? '')===$opt)?'selected':'' ?>><?= e($opt) ?></option><?php endforeach; ?>
</select>
<?php elseif ($meta['type']==='textarea'): ?>
<textarea name="<?= e($field) ?>" rows="2"><?= e($edit[$field] ?? '') ?></textarea>
<?php else: ?>
<input type="<?= e($meta['type']) ?>" name="<?= e($field) ?>" value="<?= e($edit[$field] ?? '') ?>"
<?= isset($meta['step'])?'step="'.e($meta['step']).'"':'' ?> <?= isset($meta['min'])?'min="'.e($meta['min']).'"':'' ?>
<?= !empty($meta['required'])?'required':'' ?>>
<?php endif; ?>
</div>
<?php endforeach; ?>
<?php if ($key==='users'): ?><div class="field"><label>Contraseña <?= $edit?'(dejar vacía para conservarla)':'*' ?></label><input type="password" name="password" <?= $edit?'':'required' ?> minlength="8" autocomplete="new-password"></div><?php endif; ?>
<div class="form-actions"><button class="btn primary" type="submit"><?= $edit?'Guardar cambios':'Crear registro' ?></button><?php if ($edit): ?><a class="btn secondary" href="<?= e($key) ?>.php">Cancelar</a><?php endif; ?></div>
</form>
</section>
<section class="panel">
<div class="section-title"><h2>Registros existentes</h2><span class="pill"><?= count($rows) ?> registros</span></div>
<div class="table-wrap"><table><thead><tr><?php foreach ($cfg['columns'] as $label): ?><th><?= e($label) ?></th><?php endforeach; ?><th>Acciones</th></tr></thead><tbody>
<?php if (!$rows): ?><tr><td colspan="<?= count($cfg['columns'])+1 ?>" class="empty">Todavía no hay registros.</td></tr><?php endif; ?>
<?php foreach ($rows as $row): ?><tr>
<?php foreach ($cfg['columns'] as $field=>$label): ?><td><?= e($field==='precio' ? number_format((float)$row[$field],2) : ($field==='password_hash'?'••••':$row[$field])) ?></td><?php endforeach; ?>
<td class="actions"><a class="btn tiny secondary" href="<?= e($key) ?>.php?edit=<?= (int)$row['id'] ?>">Editar</a>
<form method="post" class="inline" onsubmit="return confirm('¿Seguro que deseas eliminar este registro?');"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$row['id'] ?>"><button class="btn tiny danger" type="submit">Eliminar</button></form></td>
</tr><?php endforeach; ?>
</tbody></table></div>
</section>
<?php require 'includes/footer.php'; ?>
