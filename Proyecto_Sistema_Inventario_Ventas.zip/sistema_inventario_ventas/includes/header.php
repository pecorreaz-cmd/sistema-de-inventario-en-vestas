<?php require_once __DIR__ . '/auth.php'; ?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= isset($page_title) ? e($page_title) : 'Inventario y Ventas' ?></title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header class="topbar">
  <div class="brand">📦 Inventario y Ventas</div>
  <?php if (!empty($_SESSION['user_id'])): ?>
  <nav>
    <a href="dashboard.php">Inicio</a>
    <a href="users.php">Usuarios</a>
    <a href="products.php">Productos</a>
    <a href="clients.php">Clientes</a>
    <a href="sales.php">Ventas</a>
    <a href="logout.php">Salir</a>
  </nav>
  <?php endif; ?>
</header>
<main class="container">
