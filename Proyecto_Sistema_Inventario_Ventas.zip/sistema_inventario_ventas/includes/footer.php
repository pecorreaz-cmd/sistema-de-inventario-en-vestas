</main>
<footer class="footer">Sistema académico de gestión de inventario y ventas · Proyecto web</footer>
</body>
</html>
