<?php
require_once 'config.php';
require_once 'includes/auth.php';
require_login();
$counts = [];
foreach (['users'=>'Usuarios', 'products'=>'Productos', 'clients'=>'Clientes', 'sales'=>'Ventas'] as $table=>$label) {
    $counts[$label] = (int)$pdo->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
}
$page_title = 'Panel principal';
require 'includes/header.php';
?>
<section class="hero">
  <div><span class="eyebrow">PANEL PRINCIPAL</span><h1>¡Hola, <?= e($_SESSION['user_name']) ?>!</h1>
  <p>Administra la información de tu negocio desde un solo lugar.</p></div>
  <div class="hero-badge">📊</div>
</section>
<div class="stats">
<?php foreach ($counts as $label=>$count): ?>
  <article class="stat-card"><div class="stat-label"><?= e($label) ?></div><div class="stat-number"><?= $count ?></div><div class="stat-foot">Registros disponibles</div></article>
<?php endforeach; ?>
</div>
<section class="panel">
<h2>Accesos rápidos</h2>
<div class="quick-grid">
<a class="quick-link" href="products.php"><span>📦</span><strong>Gestionar productos</strong><small>Inventario, precios y cantidades</small></a>
<a class="quick-link" href="clients.php"><span>👥</span><strong>Gestionar clientes</strong><small>Datos y contacto de clientes</small></a>
<a class="quick-link" href="sales.php"><span>🧾</span><strong>Gestionar ventas</strong><small>Registrar y revisar ventas</small></a>
<a class="quick-link" href="users.php"><span>🔑</span><strong>Gestionar usuarios</strong><small>Accesos al sistema</small></a>
</div>
</section>
<?php require 'includes/footer.php'; ?>
